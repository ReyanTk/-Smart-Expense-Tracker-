import os
from datetime import datetime

import matplotlib.pyplot as plt

from expense_manager import ExpenseManager


class ChartGenerator:
    """Generate and save charts for expense summaries."""

    def __init__(self, manager: ExpenseManager) -> None:
        self.manager = manager
        self.charts_folder = os.path.join(os.path.dirname(__file__), "charts")
        os.makedirs(self.charts_folder, exist_ok=True)

    def save_category_pie_chart(self) -> str:
        """Create a pie chart for category spending."""
        summary = self.manager.get_category_summary()
        if summary.empty:
            raise ValueError("No expense data available to create a category chart.")

        fig, ax = plt.subplots(figsize=(8, 6))
        ax.pie(summary["amount"], labels=summary["category"], autopct="%.1f%%", startangle=140)
        ax.set_title("Spending by Category")
        file_path = os.path.join(self.charts_folder, f"category_pie_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png")
        fig.savefig(file_path, bbox_inches="tight")
        plt.close(fig)
        return file_path

    def save_monthly_bar_chart(self) -> str:
        """Create a bar chart for monthly spending."""
        summary = self.manager.get_monthly_summary()
        if summary.empty:
            raise ValueError("No expense data available to create a monthly chart.")

        fig, ax = plt.subplots(figsize=(10, 6))
        ax.bar(summary["month"], summary["amount"], color="#4C72B0")
        ax.set_title("Monthly Spending")
        ax.set_xlabel("Month")
        ax.set_ylabel("Amount ($)")
        plt.xticks(rotation=45)
        file_path = os.path.join(self.charts_folder, f"monthly_bar_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png")
        fig.savefig(file_path, bbox_inches="tight")
        plt.close(fig)
        return file_path

    def create_all_charts(self) -> None:
        """Generate both category and monthly charts."""
        try:
            pie_path = self.save_category_pie_chart()
            bar_path = self.save_monthly_bar_chart()
            print(f"Saved category chart at: {pie_path}")
            print(f"Saved monthly chart at: {bar_path}")
        except Exception as error:
            print(f"Unable to generate charts: {error}")
