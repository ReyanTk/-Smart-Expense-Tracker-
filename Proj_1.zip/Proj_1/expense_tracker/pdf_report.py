import os
from datetime import datetime

from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

from expense_manager import ExpenseManager


class PDFReportGenerator:
    """Generate a professional PDF expense report."""

    def __init__(self, manager: ExpenseManager) -> None:
        self.manager = manager
        self.reports_folder = os.path.join(os.path.dirname(__file__), "reports")
        os.makedirs(self.reports_folder, exist_ok=True)

    def export_report(self) -> None:
        """Create the PDF file based on expense data."""
        data = self.manager.get_report_data()
        if data["expense_count"] == 0:
            print("No expenses available to export.")
            return

        filename = f"expense_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
        file_path = os.path.join(self.reports_folder, filename)
        doc = SimpleDocTemplate(file_path, pagesize=letter)

        styles = {
            "title": ParagraphStyle("title", fontSize=20, leading=24, spaceAfter=12),
            "heading": ParagraphStyle("heading", fontSize=14, leading=18, textColor=colors.darkblue, spaceAfter=10),
            "normal": ParagraphStyle("normal", fontSize=11, leading=14),
        }

        story = []
        story.append(Paragraph("Smart Expense Tracker Report", styles["title"]))
        story.append(Paragraph(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", styles["normal"]))
        story.append(Spacer(1, 12))

        story.append(Paragraph("Summary", styles["heading"]))
        story.append(Paragraph(f"Total expenses: {data['expense_count']}", styles["normal"]))
        story.append(Paragraph(f"Total amount spent: ${data['total_spent']:.2f}", styles["normal"]))
        story.append(Spacer(1, 12))

        story.append(Paragraph("Top categories", styles["heading"]))
        category_rows = [["Category", "Amount ($)"]]
        for item in data["top_categories"]:
            category_rows.append([item["category"], f"{item['amount']:.2f}"])
        story.append(self.build_table(category_rows))
        story.append(Spacer(1, 12))

        story.append(Paragraph("Monthly spending", styles["heading"]))
        monthly_rows = [["Month", "Amount ($)"]]
        for _, row in data["monthly_summary"].iterrows():
            monthly_rows.append([row["month"], f"{row['amount']:.2f}"])
        story.append(self.build_table(monthly_rows))
        story.append(Spacer(1, 12))

        story.append(Paragraph("Latest expenses", styles["heading"]))
        latest_rows = [["Date", "Category", "Amount ($)", "Description"]]
        for _, row in data["latest_expenses"].iterrows():
            date_text = row["date"].strftime("%Y-%m-%d") if row["date"] is not None else "Unknown"
            latest_rows.append([date_text, row["category"], f"{row['amount']:.2f}", row["description"]])
        story.append(self.build_table(latest_rows))

        try:
            doc.build(story)
            print(f"PDF report saved to: {file_path}")
        except Exception as error:
            print(f"Failed to create PDF report: {error}")

    def build_table(self, rows: list) -> Table:
        """Build a styled table for the PDF."""
        table = Table(rows, hAlign="LEFT")
        style = TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#d8e2f1")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.black),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
            ("FONTNAME", (0, 0), (-1, -1), "Helvetica"),
            ("FONTSIZE", (0, 0), (-1, -1), 10),
            ("ALIGN", (0, 0), (-1, -1), "LEFT"),
        ])
        table.setStyle(style)
        return table
