import sys

from expense_manager import ExpenseManager
from charts import ChartGenerator
from pdf_report import PDFReportGenerator


def print_heading(title: str) -> None:
    """Print a clean heading for the terminal menu."""
    print("\n" + "=" * 60)
    print(f"{title:^60}")
    print("=" * 60)


def prompt_menu() -> None:
    """Show the main menu and respond to user choices."""
    manager = ExpenseManager()
    charter = ChartGenerator(manager)
    reporter = PDFReportGenerator(manager)

    while True:
        print_heading("Smart Expense Tracker")
        print("1) Add expense")
        print("2) View expenses")
        print("3) Category summary")
        print("4) Monthly summary")
        print("5) Generate spending charts")
        print("6) Export PDF report")
        print("7) Exit")

        choice = input("Enter your choice [1-7]: ").strip()

        if choice == "1":
            manager.add_expense_interactive()
        elif choice == "2":
            manager.show_expenses()
        elif choice == "3":
            manager.show_category_summary()
        elif choice == "4":
            manager.show_monthly_summary()
        elif choice == "5":
            charter.create_all_charts()
        elif choice == "6":
            reporter.export_report()
        elif choice == "7":
            print("Thank you for using Smart Expense Tracker. Goodbye!")
            sys.exit(0)
        else:
            print("Invalid choice. Please type a number from 1 to 7.")


if __name__ == "__main__":
    prompt_menu()
