import csv
import os
from datetime import datetime
from typing import Any, Dict, List

import pandas as pd


class ExpenseManager:
    """Manage expense data stored in a CSV file."""

    def __init__(self) -> None:
        self.folder = os.path.dirname(__file__)
        self.csv_path = os.path.join(self.folder, "expenses.csv")
        self.ensure_data_folder()
        self.expenses = self.load_expenses()

    def ensure_data_folder(self) -> None:
        """Make sure the project folders exist."""
        charts_folder = os.path.join(self.folder, "charts")
        reports_folder = os.path.join(self.folder, "reports")
        os.makedirs(charts_folder, exist_ok=True)
        os.makedirs(reports_folder, exist_ok=True)

    def load_expenses(self) -> pd.DataFrame:
        """Load expenses from CSV or generate sample data if missing."""
        if not os.path.exists(self.csv_path):
            self.create_sample_csv()

        try:
            dataframe = pd.read_csv(self.csv_path, parse_dates=["date"])
            dataframe["date"] = pd.to_datetime(dataframe["date"], errors="coerce")
            return dataframe
        except Exception as error:
            print(f"Error loading expenses: {error}")
            return pd.DataFrame(columns=["date", "category", "description", "amount"])

    def create_sample_csv(self) -> None:
        """Create sample expense data when no CSV file exists."""
        sample = [
            {"date": "2025-04-01", "category": "Groceries", "description": "Weekly groceries", "amount": 72.50},
            {"date": "2025-04-03", "category": "Transport", "description": "Bus pass", "amount": 25.00},
            {"date": "2025-04-10", "category": "Utilities", "description": "Electricity bill", "amount": 64.20},
            {"date": "2025-04-15", "category": "Entertainment", "description": "Movie night", "amount": 18.00},
            {"date": "2025-04-22", "category": "Health", "description": "Pharmacy purchase", "amount": 12.75},
        ]
        with open(self.csv_path, mode="w", newline="", encoding="utf-8") as file:
            writer = csv.DictWriter(file, fieldnames=["date", "category", "description", "amount"])
            writer.writeheader()
            writer.writerows(sample)
        print(f"Created sample expense file at {self.csv_path}")

    def save_expenses(self) -> None:
        """Save the current expenses back to the CSV file."""
        try:
            self.expenses.to_csv(self.csv_path, index=False, date_format="%Y-%m-%d")
        except Exception as error:
            print(f"Failed to save expenses: {error}")

    def add_expense(self, date: datetime, category: str, description: str, amount: float) -> None:
        """Add a new expense row to the DataFrame."""
        new_row = {
            "date": date.strftime("%Y-%m-%d"),
            "category": category.title(),
            "description": description.strip(),
            "amount": round(amount, 2),
        }
        self.expenses = pd.concat([self.expenses, pd.DataFrame([new_row])], ignore_index=True)
        self.save_expenses()
        print("Expense added successfully.")

    def add_expense_interactive(self) -> None:
        """Collect expense input from the user with validation."""
        print("\nAdd a new expense")
        date_str = input("Enter date (YYYY-MM-DD) or leave blank for today: ").strip()
        if not date_str:
            date_value = datetime.today()
        else:
            try:
                date_value = datetime.strptime(date_str, "%Y-%m-%d")
            except ValueError:
                print("Invalid date format. Use YYYY-MM-DD.")
                return

        category = input("Enter category (e.g. Groceries, Rent): ").strip()
        if not category:
            print("Category is required.")
            return

        description = input("Enter description: ").strip()
        if not description:
            print("Description is required.")
            return

        amount_text = input("Enter amount (numeric): ").strip()
        try:
            amount_value = float(amount_text)
            if amount_value <= 0:
                raise ValueError("Amount must be greater than zero.")
        except ValueError:
            print("Invalid amount. Please enter a positive number.")
            return

        self.add_expense(date_value, category, description, amount_value)

    def get_sorted_expenses(self) -> pd.DataFrame:
        """Return expenses sorted by date, most recent first."""
        try:
            return self.expenses.sort_values(by="date", ascending=False)
        except Exception:
            return self.expenses

    def show_expenses(self) -> None:
        """Display the expense list in a readable format."""
        print("\nAll expenses:")
        expenses = self.get_sorted_expenses()
        if expenses.empty:
            print("No expenses found.")
            return

        for _, row in expenses.iterrows():
            date_str = row["date"].strftime("%Y-%m-%d") if not pd.isna(row["date"]) else "Unknown"
            print(f"{date_str} | {row['category']} | ${row['amount']:.2f} | {row['description']}")

    def get_category_summary(self) -> pd.DataFrame:
        """Group expenses by category and sum the amounts."""
        if self.expenses.empty:
            return pd.DataFrame()

        summary = (
            self.expenses.groupby("category", as_index=False)["amount"]
            .sum()
            .sort_values(by="amount", ascending=False)
        )
        return summary

    def show_category_summary(self) -> None:
        """Print category totals to the terminal."""
        print("\nCategory spending summary:")
        summary = self.get_category_summary()
        if summary.empty:
            print("No expenses to summarize.")
            return

        for _, row in summary.iterrows():
            print(f"{row['category']}: ${row['amount']:.2f}")

    def get_monthly_summary(self) -> pd.DataFrame:
        """Summarize spending by month."""
        if self.expenses.empty:
            return pd.DataFrame()

        month_data = self.expenses.copy()
        month_data["month"] = month_data["date"].dt.to_period("M")
        summary = (
            month_data.groupby("month", as_index=False)["amount"]
            .sum()
            .sort_values(by="month", ascending=False)
        )
        summary["month"] = summary["month"].astype(str)
        return summary

    def show_monthly_summary(self) -> None:
        """Print the monthly spending summary."""
        print("\nMonthly spending summary:")
        summary = self.get_monthly_summary()
        if summary.empty:
            print("No monthly spending data available.")
            return

        for _, row in summary.iterrows():
            print(f"{row['month']}: ${row['amount']:.2f}")

    def get_report_data(self) -> Dict[str, Any]:
        """Build the data used by the PDF report generator."""
        total_spent = self.expenses["amount"].sum() if not self.expenses.empty else 0.0
        top_categories = self.get_category_summary().head(5).to_dict(orient="records")
        latest = self.get_sorted_expenses().head(10)
        return {
            "expense_count": len(self.expenses),
            "total_spent": total_spent,
            "top_categories": top_categories,
            "latest_expenses": latest,
            "category_summary": self.get_category_summary(),
            "monthly_summary": self.get_monthly_summary(),
        }
